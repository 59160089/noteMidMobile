//
//  ViewController.swift
//  lab1
//
//  Created by student on 30/1/2562 BE.
//  Copyright © 2562 frame. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var test1:UILabel!
    
    @IBOutlet weak var num1:UILabel!
    @IBOutlet weak var num2:UILabel!
    @IBOutlet weak var Ark:UILabel!
    
    
    var number1: Int = 0;
    var number2: Int = 0;
    var random: Int = 0;
    var ark: Int = 0;
    var text1: String = "?";
    var text2: String = "?";

    override func viewDidLoad() {
        super.viewDidLoad()
        showstart()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func showAlert(){
        
        let title: String;
        let Symbols: String;
        RandomNum()
        if random == 0{
            ark = number1+number2;
            title = "plus"
            Symbols = "+"
        }
        else if random == 1{
            ark = number1-number2;
            title = "minus"
            Symbols = "-"
        }
        else if random == 2{
            ark = number2*number1;
            title = "times"
            Symbols = "*"
        }
        else{
            ark = number1/number2;
            title = "divided by"
            Symbols = "/"
        }
        
        
        let alert = UIAlertController(title: title, message:"\(number1) \(Symbols) \(number2) = \(ark) " ,preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: {_ in self.update()})
        alert.addAction(action)
        present(alert,animated: true, completion: nil)
        update()
    }
    @IBAction func showstart(){
        number1 = 0
        number2 = 0
        random = 999
        text1 = "?"
        text2 = "?"
        update()
    }
    func RandomNum() {
        number1 = Int.random(in: 0...100);
        number2 = Int.random(in: 0...100);
        random = Int.random(in: 0...3);
        
    }
    func update(){
        num1.text = String(number1)
        num2.text = String(number2)
        
        if random == 0{
            test1.text = String("+")
        }
        else if random == 1{
            test1.text = String("-")
            
        }
        else if random == 2{
           test1.text = String("*")
            
        }
        else if random == 999{
            test1.text = String("?")
        }
        else{
            test1.text = String("/")
        }
        Ark.text = String(ark)
    }


}

