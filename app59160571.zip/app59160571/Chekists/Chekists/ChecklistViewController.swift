//
//  ViewController.swift
//  Chekists
//
//  Created by student on 13/2/2562 BE.
//  Copyright © 2562 Razeware. All rights reserved.
//

import UIKit



class ChecklistViewController: UITableViewController, AddItemViewControllerDelegate {
     var items = [ChecklistItem]()
    
    func addItemViewControllerDedCancel(_ controller: addItemTableViewController) {
        navigationController?.popViewController(animated: true)
    }
    func addItemViewController(_ controller: addItemTableViewController, didFinisshAdding item: ChecklistItem) {
        
        let newRowIndex = items.count
        
        
        items.append(item)
        print(item)
        
        
        let indexPath = IndexPath(row: newRowIndex, section: 0)
        let indexpaths = [indexPath]
        tableView.insertRows(at: indexpaths, with: .automatic)
        navigationController?.popViewController(animated: true)
    }
    
    
   
//
//    var row0item = ChecklistItem()
//    var row1item = ChecklistItem()
//    var row2item = ChecklistItem()
//    var row3item = ChecklistItem()
//    var row4item = ChecklistItem()
    
//    @IBAction func addItem(){
//        let newRowIndex = items.count
//        let item = ChecklistItem()
//        item.text = "tee"
//        item.checked = true
//        items.append(item)
//
//
//
//        let indexPath = IndexPath(row: newRowIndex, section: 0)
//        let indexpaths = [indexPath]
//        tableView.insertRows(at: indexpaths, with: .automatic)
//    }
    
    
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
//        row0item.text = "Walk the dog"
//        row1item.text = "Brush my testh"
//        row2item.text = "Learn iOS development"
//        row3item.text = "Soccer pravtice"
//        row4item.text = "Eat ice cream"
        let item0 = ChecklistItem()
        item0.text = "Walk the dog"
        item0.checked = true
        items.append(item0)
        
        let item1 = ChecklistItem()
        item1.text = "Brush my testh"
        item1.checked = true
        items.append(item1)
        
        let item2 = ChecklistItem()
        item2.text = "Learn iOS development"
        item2.checked = true
        items.append(item2)
        
        let item3 = ChecklistItem()
        item3.text = "Soccer pravtice"
        item3.checked = true
        items.append(item3)
        
        let item4 = ChecklistItem()
        item4.text = "Eat ice cream"
        item4.checked = true
        items.append(item4)
        navigationController?.navigationBar.prefersLargeTitles = true
        

        // Do any additional setup after loading the view, typically from a nib.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddItem" {
            let controller = segue.destination as! addItemTableViewController
            controller.delegate = self
        }
    }
    //MARK:- TAble View Data Source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return items.count
        
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChecklistItem",for: indexPath)
        
        let item = items[indexPath.row]
        let lable = cell.viewWithTag(1000) as! UILabel
        lable.text = item.text
        
        configureCheckmark(for: cell, with: item)
        return cell
        
//        if indexPath.row  == 0{
//
//
//            lable.text = row0item.text
//
//        }
//        else if indexPath.row  == 1{
//            lable.text = row1item.text
//        }
//        else if indexPath.row  == 2{
//            lable.text = row2item.text
//        }
//        else if indexPath.row  == 3{
//            lable.text = row3item.text
//        }
//        else if indexPath.row  == 4{
//            lable.text = row4item.text
//        }
//
//
//
//
//
//        configureCheckmark(for: cell, at: indexPath)
//        return cell
    }
    
   
    
    
    
    //add the folloing code
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if let cell = tableView.cellForRow(at: indexPath){
            
            let item = items[indexPath.row]
            item.toggleChecked()
            
            
//            if indexPath.row == 0{
//                row0item.checked = !row1item.checked
//
//            }
//            else if indexPath.row == 1{
//                row1item.checked = !row1item.checked
//
//            }
//            else if indexPath.row  == 2{
//                row2item.checked = !row2item.checked
//
//            }
//            else if indexPath.row  == 3{
//                row3item.checked = !row3item.checked
//
//            }
//            else if indexPath.row  == 4{
//                row4item.checked = !row4item.checked
//
//            }
            
            
            
            
            
            configureCheckmark(for: cell,with: item)
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
    func configureCheckmark(for cell: UITableViewCell,with item: ChecklistItem) {
        
        
        let lablel = cell.viewWithTag(1000) as! UILabel
        lablel.text = item.text
        if item.checked {
            cell.accessoryType = .checkmark
        }
        else{
             cell.accessoryType = .none
        }
//            if indexPath.row  == 0{
//                row0item.checked = !row0item.checked
//
//            }
//            else if indexPath.row  == 1{
//                row1item.checked = !row1item.checked
//
//            }
//            else if indexPath.row  == 2{
//                row2item.checked = !row2item.checked
//
//            }
//            else if indexPath.row  == 3{
//                row3item.checked = !row3item.checked
//
//            }
//            else if indexPath.row  == 4{
//                row4item.checked = !row4item.checked
//
//            }
//
//
//
//
//            if isChecked {
//                cell.accessoryType = .checkmark
//            }
//            else{
//                cell.accessoryType = .none
    }
    func configureText (for cell: UITableViewCell,with item: ChecklistItem) {
        let lable = cell.viewWithTag(1000) as! UILabel
        lable.text = item.text
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        items.remove(at: indexPath.row)
        
        let indexPaths = [indexPath]
        tableView.deleteRows(at: indexPaths, with: .automatic)
    }
    
    
}

