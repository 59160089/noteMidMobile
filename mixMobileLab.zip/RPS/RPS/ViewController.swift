//
//  ViewController.swift
//  RPS
//
//  Created by student on 30/1/2562 BE.
//  Copyright © 2562 eiei. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lbplayer1 : UILabel!
    @IBOutlet weak var lbplayer2 : UILabel!
    @IBOutlet weak var lbscoreP1 : UILabel!
    @IBOutlet weak var lbscoreP2 : UILabel!
    @IBOutlet weak var lbresult : UILabel!
    
    var score1 = 0
    var score2 = 0
    var player1 = "รอเล่น"
    var player2 = "รอเล่น"
    var result = "ผล"
    var p1 = 0
    var p2 = 0
    
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        
        
    }
    
    @IBAction func btnPlay() {
        letPlay()
    }
    
    func letPlay() {
        
         p1  = random()
         p2   = random()
        
        if( whoWin(p1: p1, p2: p2) == "ผู้เล่น1ชนะ"){//ผู้เล่น1 ชนะ
            result = "ผู้เล่น1ชนะ"
            score1 += 1
        }else if (whoWin(p1: p1, p2: p2) == "ผู้เล่น2ชนะ"){//ผู้เล่น2 ชนะ
            result = "ผู้เล่น2ชนะ"
            score2 += 1
        }else {
            result = "เสมอ"
        }
        
       
        
        updateLabel()
    }
    
    func random() -> Int{
        return Int.random(in: 1...3)
    }
    
    func whoWin(p1 : Int , p2 : Int) -> String {
        // 1 = ค้อน 2 = กระดาษ 3 = กรรไกร
        
        if(p1 == p2){
           return "เสมอ"
        }
        
        if(p1 == 1 && p2 == 2){
            return "ผู้เล่น2ชนะ"
        }else if (p1 == 1 && p2 == 3){
            return "ผู้เล่น1ชนะ"
        }else if(p1 == 2 && p2 == 3) {
              return "ผู้เล่น2ชนะ"
        }else if (p1 == 2 && p2 == 1) {
            return "ผู้เล่น1ชนะ"
        }else if (p1 == 3 && p2 == 1){
            return "ผู้เล่น2ชนะ"
        }else if (p1 == 3 && p2 == 2) {
            return "ผู้เล่น1ชนะ"
        }
        
    return "BUG!"
        
        
    }
    
    func updateLabel () {
       
        lbplayer1.text = eiei(p: p1)
        lbplayer2.text = eiei(p: p2)
        lbresult.text = result
        lbscoreP1.text = String(score1)
        lbscoreP2.text = String(score2)
        
        
    }
    
    func eiei (p : Int) -> String {
        if(p == 1 ){
            return "ค้อน"
        }else if(p == 2) {
            return "กระดาษ"
        }else {
            return "กรรไกร"
        }
    }
    
    
    


}

