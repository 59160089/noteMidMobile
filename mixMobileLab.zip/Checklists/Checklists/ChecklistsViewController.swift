//
//  ViewController.swift
//  Checklists
//
//  Created by student on 13/2/2562 BE.
//  Copyright © 2562 0089. All rights reserved.
//

import UIKit

class ChecklistsViewControllerei : UITableViewController , AddItemViewControllerDelegate {
    func addItemViewControllerDidCancel(_ controller: AddItem) {
        navigationController?.popViewController(animated:true)
    }
    
    func addItemViewController(_ controller: AddItem, didFinishAdding item: ChecklistItem) {
         navigationController?.popViewController(animated:true)
        let newRowIndex = items.count
        items.append(item)
        let indexPath = IndexPath(row: newRowIndex, section: 0)
        let indexPaths = [indexPath]
        tableView.insertRows(at: indexPaths, with: .automatic)
        navigationController?.popViewController(animated:true)
    }
    
    // MARK:- Navigation
    override func prepare(for segue: UIStoryboardSegue,
                          sender: Any?) {
        // 1
        if segue.identifier == "AddItem" {
            // 2
            let controller = segue.destination
                as! AddItem
            // 3
            controller.delegate = self
        }
    }
    
    
    
    var items = [ChecklistItem]()
    
    override func viewDidLoad() {
         super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        navigationController?.navigationBar.prefersLargeTitles = true
        
        var item = ChecklistItem()
        item.text = "walk the dog"
        item.checked = false
        items.append(item)
        
         item = ChecklistItem()
        item.text = "Brush my teeth"
                item.checked = false
        items.append(item)
        
        item = ChecklistItem()
        item.text = "Learn IOS"
                item.checked = false
        items.append(item)
        
        item = ChecklistItem()
        item.text = "Soccer practice"
                item.checked = false
        items.append(item)
        
        item = ChecklistItem()
        item.text = "Eat ice cream"
        items.append(item)
        
        item = ChecklistItem()
        item.text = "EIEI GUM TODDDD"
        items.append(item)
        
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { //number of section
        return 6
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Checklistitem" ,
                                                 for : indexPath )
        configureText(for: cell , with: items[indexPath.row])
        configureCheckmark(for : cell , with: items[indexPath.row])
        return cell
    }
    
    func configureCheckmark ( for cell : UITableViewCell , with item: ChecklistItem){
        if (item.checked) {
            item.checked = !item.checked
            cell.accessoryType = .checkmark
        }else {
            item.checked = !item.checked
            cell.accessoryType = .none
        }
    }
    
    func configureText (for cell : UITableViewCell , with item : ChecklistItem) {
        let lable = cell.viewWithTag(11) as!  UILabel
        lable.text = item.text
    }
   
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath){
            configureCheckmark(for: cell, with: items[indexPath.row])
        }
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    @IBAction func addItem() {
    let newRowIndex = items.count
        
        let item = ChecklistItem()
        item.text = "I am a new rowwww"
        items.append(item)
        
        let indexPath = IndexPath ( row : newRowIndex , section :0)
        let indexPaths = [indexPath]
        tableView.insertRows(at: indexPaths, with: .automatic)
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        items.remove(at: indexPath.row)
        
        let indexPaths = [indexPath]
        tableView.deleteRows(at: indexPaths, with: .automatic)
    }
    


}

