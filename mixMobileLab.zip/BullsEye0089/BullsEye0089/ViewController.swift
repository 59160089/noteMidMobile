//
//  ViewController.swift
//  BullsEye0089
//
//  Created by student on 9/1/2562 BE.
//  Copyright © 2562 eiei. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slider1 : UISlider!
    @IBOutlet weak var labelTargetValue : UILabel!
    @IBOutlet weak var labelScore : UILabel!
    @IBOutlet weak var labelRound : UILabel!

    
    
    
 
    
    var currentValue: Int = 2000
    var round : Int = 0
    var score : Int = 0
    var targetValue : Int = 0
 
    
    override func viewDidLoad() {
        updateLabel()
        randomTargetValues()
        currentValue = lroundf(slider1.value)
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func updateLabel() {
        labelRound.text = "\(round)"
        labelScore.text = "\(score)"
    }
    
    func newRound(_ point : Int){
        score += point
        round += 1
        slider1.value = 50
        randomTargetValues()
        updateLabel()
        
    }
    
    func randomTargetValues(){
              targetValue = Int.random(in: 1...100)
         labelTargetValue.text = "\(targetValue)"
    }
    
   @IBAction func startOver(){
    
   startNewGame()
    
    }
    
    func startNewGame () {
        round = 0
        score = 0
        randomTargetValues()
        updateLabel()
        slider1.value = 50
        currentValue = lroundf(slider1.value)
        
        let transition = CATransition()
        transition.type = CATransitionType.fade
        transition.duration = 1
        transition.timingFunction = CAMediaTimingFunction(name :CAMediaTimingFunctionName.easeOut)
        view.layer.add(transition , forKey: nil)
    }
    
    @IBAction func showAlert() {
        
        let different = calculatePoint().different
        let point = calculatePoint().point
        
        if(different == 0 ){
            buttonAlert("Perfect!!! \nBonus point*2 !!! \nand you get \(point*2) point",different)
          //  newRound(point*2)
        }else if(different <= 5 ){
          //  buttonAlert("You almost had it!\nand you get \(point) point",different)
            newRound(point)
        }else if(different <= 10){
           // buttonAlert("Pretty good!\nand you get \(point) point", different)
             newRound(point)
        }else{
            buttonAlert("not even close...\nand you get \(point) point",different)
           //  newRound(point)
        }
        
        
        
    }
    
    func calculatePoint() -> (point : Int , different : Int) {
        let differrenceValue : Int = (targetValue - currentValue)
        if(differrenceValue > 0){
            return (100 - differrenceValue , ( differrenceValue))
        }else{
            return (100 - (differrenceValue * -1) ,(differrenceValue * -1))
        }
    }
    
    func buttonAlert(_ messageTitle : String , _ differrent : Int) {
    
    let alert = UIAlertController(title : messageTitle ,
    message : "The value of the slider is : \(currentValue)" +
        "\nThe target value is : \(targetValue)" +
        "\nThe difference is : \(differrent)",
    preferredStyle : .alert)
    
    let action = UIAlertAction(title : "OK" , style : .default ,
                               handler : {_ in self.newRound(self.calculatePoint().point)} )
    
  /*
         let action1 = UIAlertAction(title : "gum " , style : .destructive ,
    handler : nil)
    
    let action2 = UIAlertAction(title : "todd" , style : .cancel ,
    handler : nil)
    */
    
    
    alert.addAction(action)
   /* alert.addAction(action1)
    alert.addAction(action2)*/
    
    present(alert, animated: true , completion: nil )
        
    }
    @IBAction func slideMoved (_ slider : UISlider){
        
        currentValue = lroundf(slider.value)
        print (  lroundf(slider.value) )
    
    }
    
    
   
    
    
}

